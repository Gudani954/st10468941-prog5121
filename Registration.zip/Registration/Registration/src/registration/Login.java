//Declaring package name
package registration;

public class Login {
    //Variables to store the entered username and password for login
    private String enteredUsername;
    private String enteredPassword;

    //Method to check if the entered username has underscore and less/equal to 5
    public static boolean checkUserName(String userName) {
        return userName != null && userName.contains("_") && userName.length() <= 5;
    }

    //Method to check the validity of the password entered
    //if all Required complexity is true the method returns true 
    public static boolean checkPasswordComplexity(String password) {
        if (password == null || password.length() < 8) return false;
        boolean hasNum = false, hasCap = false, hasSchar = false;
        for (char c : password.toCharArray()) {
            if (Character.isUpperCase(c)) hasCap = true;
            if (Character.isDigit(c)) hasNum = true;
            if (!Character.isLetterOrDigit(c)) hasSchar = true;
        }
        return hasNum && hasCap && hasSchar;
    }

    //Method to check the validity of the phonenumber entered
    public static boolean checkCellPhoneNumber(String num) {
        return num != null && num.matches("^\\+27[0-9]{9}$");
    }

    //Method to register the by the valid username, password and the phonenumber
    public String registerUser(String username, String password, String phoneNumber) {
        //Check for valid username
        boolean usernameValid = checkUserName(username);
        //Check for valid password
        boolean passwordValid = checkPasswordComplexity(password);
        //Check for valid phone number
        boolean phoneValid = checkCellPhoneNumber(phoneNumber);

        //If statement to display errors to users if validation fails
        if (!usernameValid) {
            return "Username is not correctly formatted, please ensure that your username contains an underscore and is no more than five characters in length.";
        } else if (!passwordValid) {
            return "Password is not correctly formatted, please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.";
        } else if (!phoneValid) {
            return "Cell phone number incorrectly formatted or does not contain international code.";
        } else {
            return "Username successfully captured.\nPassword successfully captured.\nCell phone number successfully added.\nUser registered successfully.";
        }
    }

    //Method to check if the entered username and password match the stored ones in when registering
    public boolean loginUser() {
        return enteredUsername != null && enteredPassword != null &&
                enteredUsername.equals(Registration.getUserName()) &&
                enteredPassword.equals(Registration.getPassword());
    }

    //Method to display messages if login fails or was successful
    public String returnLoginStatus() {
        if (loginUser()) {
            //Message to display if login is successful
            return "Welcome " + Registration.getFirstName() + ", " +
                   Registration.getLastName() + " it is great to see you again.";
        } else {
            //Message to display if login failed
            return "Username or password incorrect, please try again.";
        }
    }

    //Setter for username entered
    public void setEnteredUsername(String username) { this.enteredUsername = username; }
    //Setter for password entered
    public void setEnteredPassword(String password) { this.enteredPassword = password; }
}
